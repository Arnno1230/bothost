package com.hsnk.bothost;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.*;
import android.util.Base64;
import android.webkit.*;
import java.io.*;
import java.util.UUID;

public class MainActivity extends Activity {
    static final String PERM = "com.termux.permission.RUN_COMMAND";
    static final String URL = "http://127.0.0.1:8080/login";
    WebView w; String pw; int tries = 0;
    Handler h = new Handler(Looper.getMainLooper());

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        SharedPreferences sp = getSharedPreferences("s", 0);
        pw = sp.getString("pw", null);
        if (pw == null) { pw = UUID.randomUUID().toString().substring(0, 10); sp.edit().putString("pw", pw).apply(); }
        w = new WebView(this); setContentView(w);
        WebSettings s = w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        w.setWebViewClient(new WebViewClient() {
            @Override public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                if (r.isForMainFrame() && ++tries < 60) h.postDelayed(() -> login(), 2500);
                else if (r.isForMainFrame()) help();
            }
        });
        if (checkSelfPermission(PERM) != PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{PERM}, 1);
        else launch();
    }

    @Override public void onRequestPermissionsResult(int c, String[] p, int[] g) { launch(); }

    void launch() {
        try {
            InputStream in = getAssets().open("bot_host.py");
            ByteArrayOutputStream o = new ByteArrayOutputStream();
            byte[] bf = new byte[4096]; int n;
            while ((n = in.read(bf)) > 0) o.write(bf, 0, n);
            String b64 = Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP);
            String script = "export DEBIAN_FRONTEND=noninteractive; command -v python >/dev/null || pkg install -y python; "
                + "python -c 'import flask' 2>/dev/null || pip install -q flask; termux-wake-lock; "
                + "echo " + b64 + " | base64 -d > ~/bot_host.py; cd ~; PANEL_PASSWORD=" + pw + " exec python bot_host.py";
            Intent i = new Intent("com.termux.RUN_COMMAND");
            i.setClassName("com.termux", "com.termux.app.RunCommandService");
            i.putExtra("com.termux.RUN_COMMAND_PATH", "/data/data/com.termux/files/usr/bin/bash");
            i.putExtra("com.termux.RUN_COMMAND_ARGUMENTS", new String[]{"-c", script});
            i.putExtra("com.termux.RUN_COMMAND_WORKDIR", "/data/data/com.termux/files/home");
            i.putExtra("com.termux.RUN_COMMAND_BACKGROUND", true);
            startService(i);
            h.postDelayed(() -> login(), 3000);
        } catch (Exception e) { help(); }
    }

    void login() { w.postUrl(URL, ("p=" + pw).getBytes()); }

    void help() {
        w.loadData("<body style='background:#0f1115;color:#eee;font-family:sans-serif;padding:16px'>"
            + "<h3>প্রথমবার সেটআপ</h3><ol><li>F-Droid বা GitHub থেকে <b>Termux</b> ইনস্টল করুন</li>"
            + "<li>Termux খুলে লিখুন:<br><code>mkdir -p ~/.termux &amp;&amp; echo allow-external-apps=true &gt;&gt; ~/.termux/termux.properties</code></li>"
            + "<li>Termux থেকে <code>exit</code> দিয়ে বের হন, তারপর এই অ্যাপ বন্ধ করে আবার খুলুন ও অনুমতি দিন</li>"
            + "<li>প্রথমবার পাইথন ইনস্টল হতে কয়েক মিনিট লাগবে</li></ol></body>", "text/html; charset=utf-8", "UTF-8");
    }

    @Override public void onBackPressed() { if (w.canGoBack()) w.goBack(); else moveTaskToBack(true); }
}
