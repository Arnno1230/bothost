#!/usr/bin/env python3
"""HSNK Bot Host - অনেকগুলো টেলিগ্রাম বট একসাথে চালানোর ফ্রি হোস্টিং প্যানেল।
Run:  pip install flask  &&  python bot_host.py
"""
import os, re, sys, json, time, shutil, signal, zipfile, secrets, hmac, subprocess, threading
from pathlib import Path
from functools import wraps
from flask import Flask, request, session, redirect, jsonify, render_template_string

BASE = Path(__file__).parent.resolve()
BOTS = BASE / "bots"; BOTS.mkdir(exist_ok=True)
CFG = BASE / "config.json"
PORT = int(os.environ.get("PORT", 8080))
lock = threading.RLock()
procs = {}

# ---------- config ----------
def save():
    with lock: CFG.write_text(json.dumps(cfg, indent=1))

if CFG.exists():
    cfg = json.loads(CFG.read_text())
else:
    pw = os.environ.get("PANEL_PASSWORD") or secrets.token_urlsafe(6)
    cfg = {"password": pw, "secret": secrets.token_hex(16), "bots": {}}
    save()
    print(f"\n*** প্যানেল পাসওয়ার্ড: {pw} ***  (config.json এ পাল্টাতে পারবেন)\n")

if os.environ.get("PANEL_PASSWORD"): cfg["password"] = os.environ["PANEL_PASSWORD"]

# ---------- process control ----------
def safe(n): return re.sub(r"[^A-Za-z0-9_-]", "_", n or "")[:40]
def running(n): p = procs.get(n); return bool(p and p.poll() is None)

def kill(p, sig):
    try:
        if os.name == "nt": p.kill()
        else: os.killpg(p.pid, sig)
    except Exception: pass

def start(n):
    with lock:
        b = cfg["bots"].get(n)
        if running(n) or not b or not b.get("main") or not (BOTS / n / b["main"]).exists(): return
        d = BOTS / n; lg = d / "_host.log"
        if lg.exists() and lg.stat().st_size > 1_000_000: lg.write_bytes(lg.read_bytes()[-200_000:])
        lf = open(lg, "ab"); lf.write(f"\n[{time.strftime('%F %T')}] ▶ start {b['main']}\n".encode()); lf.flush()
        kw = {} if os.name == "nt" else {"start_new_session": True}
        procs[n] = subprocess.Popen([sys.executable, "-u", b["main"]], cwd=d, stdout=lf,
                                    stderr=subprocess.STDOUT, **kw)
        b["run"] = True; save()

def stop(n, keep=False):
    with lock:
        p = procs.get(n)
        if p and p.poll() is None:
            kill(p, signal.SIGTERM)
            try: p.wait(5)
            except subprocess.TimeoutExpired: kill(p, signal.SIGKILL)
        if not keep and n in cfg["bots"]: cfg["bots"][n]["run"] = False; save()

def install(n):
    d = BOTS / n; r = d / "requirements.txt"
    if not r.exists(): return
    def job():
        with open(d / "_host.log", "ab") as lf:
            lf.write(b"\n[pip install requirements.txt ...]\n"); lf.flush()
            cmd = [sys.executable, "-m", "pip", "install", "-r", str(r)]
            if subprocess.call(cmd, stdout=lf, stderr=subprocess.STDOUT):
                subprocess.call(cmd + ["--break-system-packages"], stdout=lf, stderr=subprocess.STDOUT)
            lf.write(b"[pip done]\n")
    threading.Thread(target=job, daemon=True).start()

def monitor():  # ক্র্যাশ করলে অটো রিস্টার্ট
    while True:
        time.sleep(5)
        for n, b in list(cfg["bots"].items()):
            if b.get("run") and not running(n):
                try: start(n)
                except Exception: pass

def detect(d):
    for c in ("main.py", "bot.py", "app.py", "index.py"):
        if (d / c).exists(): return c
    py = sorted(p.name for p in d.glob("*.py"))
    return py[0] if py else ""

# ---------- web ----------
app = Flask(__name__)
app.secret_key = cfg["secret"]
app.config.update(MAX_CONTENT_LENGTH=200 * 1024 * 1024, SESSION_COOKIE_SAMESITE="Lax")

def auth(f):
    @wraps(f)
    def w(*a, **k):
        if not session.get("ok"):
            return (jsonify(ok=False), 401) if request.path.startswith("/api") else redirect("/login")
        return f(*a, **k)
    return w

@app.route("/login", methods=["GET", "POST"])
def login():
    err = ""
    if request.method == "POST":
        if hmac.compare_digest(request.form.get("p", ""), str(cfg["password"])):
            session["ok"] = True; return redirect("/")
        err = "ভুল পাসওয়ার্ড"; time.sleep(1)
    return render_template_string(LOGIN, err=err)

@app.route("/api/list")
@auth
def lst():
    return jsonify(bots=[{"name": n, "main": b.get("main", ""), "running": running(n)} for n, b in cfg["bots"].items()])

@app.post("/api/upload")
@auth
def upload():
    name = safe(request.form.get("name")); files = request.files.getlist("files")
    if not name or not files: return jsonify(ok=False, msg="নাম ও ফাইল দিন"), 400
    d = BOTS / name; d.mkdir(exist_ok=True); root = str(d.resolve()) + os.sep
    was = running(name)
    if was: stop(name, keep=True)
    for f in files:
        fn = os.path.basename(f.filename or "")
        if not fn: continue
        if fn.lower().endswith(".zip"):
            tmp = d / "_u.zip"; f.save(tmp)
            with zipfile.ZipFile(tmp) as z:
                for m in z.infolist():
                    t = (d / m.filename).resolve()
                    if not str(t).startswith(root): continue
                    if m.is_dir(): t.mkdir(parents=True, exist_ok=True)
                    else: t.parent.mkdir(parents=True, exist_ok=True); t.write_bytes(z.read(m))
            tmp.unlink()
            items = [x for x in d.iterdir() if x.name != "_host.log"]
            if len(items) == 1 and items[0].is_dir():  # একটাই ফোল্ডার থাকলে উপরে তুলে আনা
                sub = items[0]
                for x in list(sub.iterdir()): shutil.move(str(x), str(d / x.name))
                sub.rmdir()
        else:
            f.save(d / fn)
    b = cfg["bots"].setdefault(name, {"main": "", "run": False})
    m = os.path.basename(request.form.get("main", "").strip())
    b["main"] = m or (b["main"] if b["main"] and (d / b["main"]).exists() else detect(d))
    save(); install(name)
    if was: start(name)
    return jsonify(ok=True)

@app.post("/api/<act>/<name>")
@auth
def action(act, name):
    name = safe(name)
    if name not in cfg["bots"]: return jsonify(ok=False), 404
    if act == "start": start(name)
    elif act == "stop": stop(name)
    elif act == "restart": stop(name, keep=True); start(name)
    elif act == "install": install(name)
    elif act == "delete":
        stop(name); shutil.rmtree(BOTS / name, ignore_errors=True)
        cfg["bots"].pop(name, None); procs.pop(name, None); save()
    else: return jsonify(ok=False), 400
    return jsonify(ok=True)

@app.route("/api/log/<name>")
@auth
def log(name):
    f = BOTS / safe(name) / "_host.log"
    if not f.exists(): return jsonify(log="(এখনো কোনো লগ নেই)")
    with open(f, "rb") as fh:
        fh.seek(0, 2); s = fh.tell(); fh.seek(max(0, s - 20000))
        return jsonify(log=fh.read().decode("utf-8", "replace"))

@app.route("/")
@auth
def index(): return PAGE

LOGIN = """<!doctype html><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1">
<body style="background:#0f1115;color:#eee;font-family:sans-serif;display:grid;place-items:center;height:100vh;margin:0">
<form method=post style="display:grid;gap:10px;width:260px"><h3>🔐 বট হোস্ট</h3>
<input type=password name=p placeholder="পাসওয়ার্ড" autofocus style="padding:12px;border-radius:8px;border:0">
<button style="padding:12px;border-radius:8px;border:0;background:#2f81f7;color:#fff">লগইন</button>
<small style="color:#f66">{{err}}</small></form>"""

PAGE = """<!doctype html><html lang=bn><head><meta charset=utf-8>
<meta name=viewport content="width=device-width,initial-scale=1"><title>বট হোস্ট</title>
<style>
[hidden]{display:none!important}
body{background:#0f1115;color:#eee;font-family:sans-serif;margin:0;padding:12px;max-width:640px;margin:auto}
.card{background:#1a1d24;border-radius:12px;padding:12px;margin:10px 0;display:grid;gap:8px}
input{padding:10px;border-radius:8px;border:0;background:#0f1115;color:#eee}
button{padding:8px 10px;border:0;border-radius:8px;background:#2f81f7;color:#fff}
button.r{background:#d1423b}button.g{background:#2ea043}button.y{background:#6e7681}
.row{display:flex;gap:6px;flex-wrap:wrap}
.dot{display:inline-block;width:10px;height:10px;border-radius:50%;background:#d1423b;margin-right:6px}
.dot.on{background:#2ea043}small{color:#8b949e}
.modal{position:fixed;inset:0;background:#000c;display:flex;padding:10px}
.modal>div{background:#1a1d24;border-radius:12px;padding:10px;flex:1;display:flex;flex-direction:column;min-width:0}
pre{flex:1;overflow:auto;background:#0f1115;padding:8px;border-radius:8px;font-size:12px;white-space:pre-wrap;word-break:break-all}
</style></head><body>
<h3>🤖 টেলিগ্রাম বট হোস্টিং প্যানেল</h3>
<div class=card><b>নতুন বট আপলোড</b>
<input id=n placeholder="বটের নাম (ইংরেজিতে, যেমন shop_bot)">
<input id=m placeholder="মেইন ফাইল (ঐচ্ছিক, যেমন bot.py)">
<input id=f type=file multiple>
<small>.py ফাইল, requirements.txt, বা পুরো .zip দিতে পারবেন</small>
<button onclick=up()>⬆ আপলোড</button></div>
<div id=list></div>
<div id=lg class=modal hidden><div><div class=row><b id=lt style="flex:1"></b><button class=y onclick=closeLog()>✕</button></div><pre id=lp></pre></div></div>
<script>
const $=s=>document.querySelector(s);
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
async function api(u,o){const r=await fetch(u,o);if(r.status==401){location='/login';return}return r.json()}
async function load(){const d=await api('/api/list');if(!d)return;
$('#list').innerHTML=d.bots.map(b=>`<div class=card><div><span class="dot ${b.running?'on':''}"></span><b>${b.name}</b> <small>${esc(b.main||'⚠ মেইন ফাইল নেই')}</small></div>
<div class=row><button class=g onclick="act('start','${b.name}')">▶ Start</button><button class=r onclick="act('stop','${b.name}')">■ Stop</button>
<button onclick="act('restart','${b.name}')">⟳</button><button class=y onclick="act('install','${b.name}')">📦 pip</button>
<button class=y onclick="showLog('${b.name}')">📜 Log</button><button class=r onclick="act('delete','${b.name}')">🗑</button></div></div>`).join('')||'<p><small>কোনো বট নেই</small></p>'}
async function act(a,n){if(a=='delete'&&!confirm(n+' ডিলিট করবেন?'))return;await api('/api/'+a+'/'+n,{method:'POST'});load()}
async function up(){const fd=new FormData();fd.append('name',$('#n').value);fd.append('main',$('#m').value);
for(const f of $('#f').files)fd.append('files',f);
const d=await api('/api/upload',{method:'POST',body:fd});if(d&&!d.ok)alert(d.msg||'ব্যর্থ');else{$('#f').value='';load()}}
let ln=null,tm;function showLog(n){ln=n;$('#lg').hidden=false;$('#lt').textContent=n;clearTimeout(tm);pollLog()}
async function pollLog(){if(!ln)return;const d=await api('/api/log/'+ln);if(!d||!ln)return;const p=$('#lp');p.textContent=d.log;p.scrollTop=p.scrollHeight;tm=setTimeout(pollLog,2000)}
function closeLog(){ln=null;clearTimeout(tm);$('#lg').hidden=true}
setInterval(load,4000);load();
</script></body></html>"""

if __name__ == "__main__":
    for n, b in list(cfg["bots"].items()):
        if b.get("run"): start(n)
    threading.Thread(target=monitor, daemon=True).start()
    print(f"প্যানেল চালু: http://localhost:{PORT}")
    app.run(host="0.0.0.0", port=PORT, threaded=True)
